//Wilson Chiu APCS2
package textExcel;
public class PercentCell extends RealCell{
	private String value = "";
	private double percent = 0.0;
	
	public PercentCell(String input){
		this.value = input;
		//stores value in parent class
		setRealCell(input);
	}
	public double getDoubleValue(){
		//turn into decimal form
		percent = Double.parseDouble(value.substring(0, value.length()-1))/100;
		return percent;
	}
}
